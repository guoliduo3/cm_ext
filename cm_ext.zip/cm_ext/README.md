* # Cloudera Manager扩展

  用于创建Cloudera Manager扩展的文档和工具

  - 工具在此git repo中
  - 包裹和CSD的验证器
  - make_manifest脚本为包裹存储库创建清单

需求
------------

* 验证包的环境要求
  * Java 7 or 8
  * Maven 3.X
* make_manifest
  * Python 2.7/3.3 或者更高版本

运行验证器
---------------------

构建验证器之前请确保安装了 jre 和 maven。

构建举例：

```bash
1. [root@cdh-001 ~]# mkdir -p /github/cloudera
2. [root@cdh-001 ~]# cd /github/cloudera
3. [root@cdh-001 cloudera]# git clone https://github.com/cloudera/cm_ext.git
4. [root@cdh-001 cloudera]# cd cm_ext
5. [root@cdh-001 cm_ext]# mvn package
```